/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstsayonunittesting;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 3rdyearaccount
 */
public class ASquareOfANumberTest {
    
    public ASquareOfANumberTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class ASquareOfANumber.
     */
   /* @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        ASquareOfANumber.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }*/

    /**
     * Test of square method, of class ASquareOfANumber.
     */
    @Test
    public void testSquare1() throws FileNotFoundException {
        
        Scanner scInput=new Scanner(new File("src/TestCases/A3.in"));
        Scanner scOutput=new Scanner(new File("src/TestCases/A3.out")); 
        
        int TestCases=scInput.nextInt();
        while(TestCases>0){
        int num = scInput.nextInt();
        int actualResult=ASquareOfANumber.square(num);
        String expResult = scOutput.nextLine();
       // int result = ASquareOfANumber.square(num);
        assertEquals(expResult, actualResult);
        }
        
        System.out.println("################");
        System.out.println("Test Case 3: Passed");
        System.out.println("################");
      //  System.out.println("square");
       
        // TODO review the generated test code and remove the default call to fail.
       //fail("The test case is a prototype.");
    }
    
}
