
package myfirstsayonunittesting;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ASquareOfANumber {

    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc=new Scanner(new File("src/TestCases/A3.in"));
        
        int TestCases =sc.nextInt();
        while(TestCases>0){
            int num=sc.nextInt();
            if (square(num)==-1)
            {
                System.out.println("INVALID");
            }
            
            else if(square(num)==1)
            {
                System.out.println("TOO BIG");
            }
            
            else
            {
               System.out.println(""+square(num));
            }
            TestCases--;
            
        }
    }
        
        public static int square(int num)
        {
            if (num<0)
        {
            return -1;
        }
        
        else if(num>999)
        {
            return 1;
        }
        
        else
        {
            int sq=num*num;
            return num*num;
        }
        }
        
    
   /* Scanner s=new Scanner(System.in);
    ASquareOfANumber squ=new ASquareOfANumber();
    int counter;
    
    System.out.println("Enter number of trials: ");
    int numOfTrials=s.nextInt();
    int[] array=new int [numOfTrials];
    
    for (counter=0; counter<numOfTrials;counter++)
    {
      array[counter]=s.nextInt();
      squ.square(array[counter]);
    }
    
   for (counter=0; counter<numOfTrials;counter++)
    {
       if (squ.square(array[counter])==-1)
       {
           System.out.println("Invalid");
       }
       
       else if(squ.square(array[counter])==1)
       {
           System.out.println("Too Big");
       }
       
       else
       {
           System.out.println(""+squ.square(array[counter]));
       }
    }
   
    }
    
    private int square(int num)
    {
        if (num<0)
        {
            return -1;
        }
        
        else if(num>999)
        {
            return 1;
        }
        
        else
        {
            int sq=num*num;
            return sq;
        }*/
    
    
    
}

